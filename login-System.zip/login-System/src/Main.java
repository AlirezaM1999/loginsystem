public class Main {
    public static void main(String[] args) {

        IDandPasswords IDpass = new IDandPasswords();



        LoginPage loginpage = new LoginPage(IDpass.getLoginInfo());
    }
}
