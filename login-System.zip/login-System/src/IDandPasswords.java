import java.util.HashMap;

public class IDandPasswords {
    HashMap<String,String> loginInfo = new HashMap<>();

    IDandPasswords(){
        loginInfo.put("Alireza","pizza");
        loginInfo.put("john","password123");
        loginInfo.put("kate","1234");
    }

    protected HashMap getLoginInfo (){
        return loginInfo;
    }
}
